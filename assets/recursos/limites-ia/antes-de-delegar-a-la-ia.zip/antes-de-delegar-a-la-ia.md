# Antes de delegar a la IA

Creado por Stephano, @iOStephano, 8pluscore.com
Basado en el curso **AI capabilities and limitations** de Anthropic, publicado en Claude Academy.

---

## Cómo usarlo

1. Antes de pedirle una tarea importante a la IA, revisa las 4 preguntas de la parte 1.
2. Usa los prompts de la parte 2 para probar cómo responde la IA con tus propias tareas.
3. Si una respuesta no te sirvió, usa el prompt de la parte 3 para entender qué falló y cómo corregirlo.

Los prompts funcionan en Claude y en otros asistentes de IA. Reemplaza lo que está entre corchetes.

---

## Parte 1. Las 4 preguntas antes de delegar

La IA no acierta en todo ni falla en todo. Falla en puntos que se pueden prever. Estas preguntas te ayudan a ubicar tu tarea.

### 1. ¿El tema es muy conocido o tiene poca información?
La IA escribe prediciendo el texto más probable. En temas con poca información, puede inventar datos que suenan bien.
**Ajuste:** verifica nombres, cifras, citas y enlaces por tu cuenta. Si puedes, pídele que trabaje con fuentes reales, como la búsqueda web o tus propios documentos.

### 2. ¿El tema es reciente o es estable?
El conocimiento de la IA tiene una fecha de corte. Lo que pasó después no lo sabe, a menos que use búsqueda web o que tú le des la información.
**Ajuste:** si el tema es reciente, activa la búsqueda web o pega el documento actualizado en la conversación.

### 3. ¿Lo que le das cabe cómodo en la conversación?
La IA solo trabaja con lo que está en la conversación, y ese espacio tiene un límite. En conversaciones largas, lo que dijiste al inicio recibe menos atención.
**Ajuste:** pon lo más importante al inicio, divide los documentos largos en partes y repite las instrucciones críticas. Si la conversación ya está muy larga, abre una nueva con lo esencial al inicio.

### 4. ¿Tus instrucciones son concretas?
La IA sigue bien las instrucciones, pero puede cumplir lo que escribiste sin entender lo que querías lograr.
**Ajuste:** di el objetivo, no solo el formato. En tareas largas, revisa el avance por partes en vez de esperar al final.

---

## Parte 2. Prompts para probar a la IA con tus tareas

### Prompt 1. Mapa de riesgos
```
Estas son tareas que hago o quiero hacer con IA:
[lista de 4 a 6 tareas concretas]

Para cada una, dime una forma en que podría salir mal si no presto atención, y qué debería revisar yo antes de usar el resultado.
```

### Prompt 2. Qué tanto sabe del tema
```
Quiero que me ayudes con este tema: [tema].

Antes de responder, dime:
1. Qué partes del tema conoces bien y cuáles menos.
2. Qué información podría estar desactualizada por tu fecha de corte.
3. Qué datos de tu respuesta debería verificar yo en otra fuente.
```

### Prompt 3. Qué recuerda de la conversación
Úsalo después de una conversación larga.
```
Resume las instrucciones, reglas y restricciones que te di al inicio de esta conversación. No agregues nada que yo no haya dicho.
```
Compara el resumen con lo que pediste. Si falta algo, repítelo o abre una conversación nueva con lo esencial al inicio.

### Prompt 4. Qué entendió que quieres
Úsalo antes de una tarea larga.
```
Te voy a pedir esta tarea: [tarea].
El objetivo es: [para qué lo necesitas].

Antes de empezar, explícame con tus palabras qué entendiste que quiero lograr, y dime qué parte no está clara o podrías interpretar de otra forma.
```

---

## Parte 3. Entender por qué falló una respuesta

Según el curso, la mayoría de las fallas aparecen cuando se cruzan 2 propiedades de la IA. Saber cuáles se cruzaron te dice qué ajuste hacer.

| Lo que pasó | Qué se cruzó | Ajuste |
|---|---|---|
| Te dio un dato, una cita o una fuente que no existe | Predicción de texto y falta de conocimiento | Verifica por tu cuenta o usa fuentes reales |
| Olvidó las reglas que le diste al inicio | Memoria de la conversación e instrucciones | Repite lo crítico o abre una conversación nueva |

### Prompt 5. Diagnóstico de la falla
```
Esta respuesta no me sirvió.
Te pedí: [lo que pediste].
Me diste: [lo que respondió].
El problema fue: [qué estuvo mal].

Según estas 4 propiedades de la IA, que son predicción de texto, conocimiento, memoria de la conversación y seguimiento de instrucciones, dime cuáles se cruzaron en esta falla y por qué. Luego dime cuál es el ajuste más concreto para corregirla.
```
Ojo. La IA puede darte la razón demasiado rápido. Si no estás de acuerdo con su diagnóstico, díselo y pídele que lo revise.

---

## Límite honesto

Esta lista no elimina los errores de la IA, pero reduce el riesgo de usar una respuesta equivocada sin darte cuenta. La IA también puede equivocarse al explicar sus propias fallas, y la decisión final siempre es tuya. Los modelos cambian, pero el curso explica que estas propiedades se mantienen aunque sus límites se muevan.

---

## Fuentes

Consultadas el 4 de noviembre de 2026.
- Anthropic, curso AI capabilities and limitations, Claude Academy. https://academy.claude.com/courses/ai-capabilities-and-limitations
- Lección When Properties Collide. https://academy.claude.com/courses/ai-capabilities-and-limitations/when-properties-collide
- Lección Next Steps. https://academy.claude.com/courses/ai-capabilities-and-limitations/next-steps
