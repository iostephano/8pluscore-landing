# Guía para usar la IA en tu pequeño negocio

Creado por Stephano, @iOStephano, 8pluscore.com
Basado en el curso **AI Fluency for small businesses** de Anthropic y PayPal, publicado en Claude Academy.

---

## Cómo usarlo

1. Empieza por el prompt 1. La ficha de tu negocio sirve para todos los demás.
2. Sigue los prompts en orden, del 2 al 5, con una sola tarea a la vez.
3. Antes de compartir cualquier documento de tu negocio, revisa la lista de privacidad de la parte 1.

Funciona en Claude y en otros asistentes de IA. Reemplaza lo que está entre corchetes.

---

## Parte 1. Antes de compartir datos de tu negocio

- Quita nombres de clientes, direcciones, teléfonos y correos. Reemplázalos por "Cliente A" o "Proveedor X".
- Quita datos de pago, cuentas bancarias y precios internos que no hagan falta para la tarea.
- Comparte solo lo que la IA necesita para esa tarea, no todo el documento por costumbre.
- Revisa los términos y la configuración de privacidad de tu herramienta y de tu plan. Algunas herramientas pueden usar lo que escribes para entrenar sus modelos.
- Si compartiste algo por error, borra la conversación y revisa cómo pedir que eliminen esos datos.

---

## Parte 2. Prompts

### Prompt 1. La ficha de tu negocio
```
Tengo un pequeño negocio y quiero armar una ficha de contexto que pueda pegar al inicio de futuras conversaciones contigo.

Entrevístame con una pregunta a la vez sobre:
1. A qué se dedica el negocio, qué ofrece y quiénes son mis clientes.
2. Mi rol y el de mi equipo.
3. Los valores y estándares que no estoy dispuesto a negociar.
4. Los problemas que más tiempo me quitan.
5. Para qué quiero usar la IA.

Cuando termines, resume todo en una ficha corta y ordenada, lista para copiar.
```

### Prompt 2. Qué tareas delegar
```
[Pega aquí la ficha de tu negocio]

Estas son tareas que hago cada semana:
[lista de 5 a 10 tareas, con cuánto tiempo toma cada una y cada cuánto la hago]

Sepáralas en 3 grupos:
1. La IA puede hacerlas, porque son respuestas estándar o procesos claros.
2. La IA prepara un borrador y yo decido antes de enviarlo.
3. Solo las hago yo, porque son decisiones importantes, temas delicados o requieren mi criterio.

Para cada tarea, explica por qué va en ese grupo y qué pasaría si sale mal. Al final, dime cuál me ahorraría más tiempo para empezar.
```

### Prompt 3. Describir la tarea antes de delegarla
```
Quiero que me ayudes con esta tarea de mi negocio: [tarea].

1. Resultado. Lo que debes entregarme es [qué esperas], a partir de [qué información te voy a dar].
2. Proceso. Primero [paso], luego [paso]. Si pasa [situación], [qué hacer]. Si no estás seguro de algo, dilo y márcalo para que yo lo revise.
3. Comportamiento. Usa un tono [tono]. Nunca [algo que no debe hacer, por ejemplo, prometer fechas o descuentos].

Antes de empezar, dime qué información te falta.
```

### Prompt 4. Probar con casos pasados
Usa casos donde ya sabes cuál era la respuesta correcta.
```
Te voy a dar [número] casos pasados de mi negocio, sin datos personales. Aplica las instrucciones que te di para cada uno.
[casos]

Después de tu respuesta, te diré lo que realmente pasó en cada caso, y quiero que me ayudes a ver qué acertaste, qué te faltó y qué inventaste.
```
Compara su respuesta con lo que ya sabías. Si después de varios intentos no logras resultados confiables, no delegues esa tarea.

### Prompt 5. Tu política de uso de IA
```
[Pega aquí la ficha de tu negocio]

Ayúdame a redactar una política de uso de IA de 1 página para mi negocio, con 3 secciones:
1. Para qué usamos la IA, con tareas y herramientas concretas.
2. Qué sigue siendo trabajo humano y por qué.
3. Cómo nos hacemos responsables, quién revisa los resultados, cómo informamos a clientes y equipo, y qué hacemos si algo sale mal.

Escríbela en un lenguaje simple. Luego dime qué partes debería revisar yo, porque solo yo conozco mi negocio.
```
Léela, corrige lo que no suene a tu negocio y quita lo que no sea cierto.

---

## Límite honesto

La IA no responde siempre igual, aunque le des las mismas instrucciones. Por eso una prueba que salió bien no garantiza que siempre salga bien, y conviene seguir revisando, sobre todo en tareas que llegan a tus clientes. Esta guía no reemplaza tu criterio ni una revisión legal. Si en tu país o tu rubro hay reglas sobre avisar del uso de IA o proteger datos personales, revísalas antes de aplicar una automatización.

---

## Fuentes

Consultadas el 4 de noviembre de 2026.
- Anthropic y PayPal, curso AI Fluency for small businesses, Claude Academy. https://academy.claude.com/courses/ai-fluency-for-small-businesses
- Lección The 4D Framework. https://academy.claude.com/courses/ai-fluency-for-small-businesses/the-4d-framework
- Lección Transparent AI use. https://academy.claude.com/courses/ai-fluency-for-small-businesses/using-data-with-ai
- Lección Tying it all together. https://academy.claude.com/courses/ai-fluency-for-small-businesses/tying-it-all-together
- Lección Human in the loop. https://academy.claude.com/courses/ai-fluency-for-small-businesses/human-in-the-loop
