# Kit: Ordena tu escritorio con Claude Cowork

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el caso de uso **Organize files across your desktop** de Claude Academy, de Anthropic.
Producto: Claude Cowork en la app de escritorio de Claude.

---

## Qué es este kit

Una lista de seguridad y prompts en español para que Claude Cowork lea tus archivos, entienda qué son por su contenido y los ordene en carpetas, con un resumen de qué movió y adónde.

## Lista de seguridad antes de dar acceso

Revisa estos 7 puntos antes del primer prompt.

- [ ] Tengo una copia de seguridad reciente, por ejemplo con Time Machine o en la nube.
- [ ] Voy a empezar por una sola carpeta, como Descargas, y no por todo el escritorio.
- [ ] Sé qué carpetas no se deben tocar, por ejemplo un proyecto en curso.
- [ ] Sé qué tipos de archivo considero basura y cuáles nunca se borran.
- [ ] Entiendo que los archivos que Claude usa se procesan en los servidores de Anthropic.
- [ ] Voy a dejar abierta la app de escritorio de Claude mientras trabaja.
- [ ] Voy a revisar el resumen final antes de dar el trabajo por terminado.

---

## Paso 1. Prepara Cowork

1. Abre la app de escritorio de Claude y entra a Cowork.
2. Usa la opción de trabajar en una carpeta y elige solo la carpeta que vas a ordenar.
3. Cuando veas cómo trabaja, puedes ampliar el acceso.

## Paso 2. Prompt principal

```text
Ayúdame a ordenar esta carpeta.
Revisa cada archivo, entiende qué es por su contenido y no solo por su nombre, y organízalo en carpetas con nombres claros.
No toques la carpeta [nombre de la carpeta que no se debe mover].
Antes de borrar cualquier archivo, pregúntame.
Al terminar, dame un resumen de cuántos archivos había, qué carpetas creaste, qué moviste a cada una y qué eliminaste.
```

## Paso 3. Usa tu propia lógica

Si ordenas por cliente, por fecha o por proyecto, díselo.

```text
Reorganiza las carpetas por [cliente / año y mes / proyecto].
Dentro de cada una, separa documentos, imágenes y videos.
Muéstrame la nueva estructura antes de mover nada.
```

## Paso 4. Encuentra algo que se perdió

```text
¿Dónde quedó el archivo del presupuesto del tercer trimestre? Creo que se llamaba algo como presupuesto_Q3.
```

## Paso 5. Deja un sistema para que no vuelva el desorden

```text
Propón un sistema simple de carpetas para mis descargas y mi escritorio.
Explícame en una lista corta dónde debe ir cada tipo de archivo nuevo para que no se vuelva a acumular.
```

---

## Cómo revisar el resultado

1. Lee la lista de lo que eliminó y confirma que solo era basura real.
2. Abre 2 o 3 archivos en las carpetas nuevas y comprueba que están donde los buscarías.
3. Ajusta la revisión al riesgo. Para capturas de pantalla basta un vistazo. Para contratos, facturas o documentos de impuestos, revisa con más cuidado.

## Límites honestos

- Ordenar muchos archivos toma tiempo. Mientras trabaja puedes abrir otra sesión para otra tarea.
- Cowork solo ve las carpetas que conectas y con los permisos que das, pero lo que lee se procesa en la nube de Anthropic. No conectes carpetas con información que no deba salir de tu computadora.
- Puede equivocarse al clasificar un archivo. Por eso conviene empezar por una carpeta y revisar.
- La disponibilidad de Cowork depende de tu plan.

## Fuentes

- Claude Academy, caso de uso Organize files across your desktop. https://academy.claude.com/use-cases/organize-files-by-whats-in-them. Consultado el 4 de noviembre de 2026.
