# Kit: Crea tu portafolio web con Claude

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el caso de uso **Create a custom webpage** de Claude Academy, de Anthropic.
Producto: chat de Claude, en claude.ai.

---

## Qué es este kit

Prompts en español para que Claude cree una página de portafolio con tu CV y tus proyectos, la mejore con detalles de diseño y te guíe para publicarla en internet con Netlify.

## Antes de empezar

Prepara 3 tipos de archivos para subir al chat.

1. **Tu historia profesional.** CV, descripción de tus proyectos y logros.
2. **Tus referencias de diseño.** Capturas de pantalla de 2 o 3 portafolios que te gusten.
3. **Imágenes de tus proyectos**, si quieres que aparezcan.

Para publicar necesitas una cuenta en Netlify y conectar Netlify a Claude desde los conectores.

---

## Paso 1. Prompt principal

```text
Ayúdame a crear una página de portafolio profesional en HTML para mostrar mi carrera y mis logros.
Subí mi CV, la descripción de mis proyectos y algunas referencias de diseño. Úsalos para entender mi experiencia y el estilo que me gusta.

Dirección de diseño.
Quiero algo sofisticado y editorial, no una plantilla corporativa.
Evita los diseños genéricos, los degradados que se ven hechos con IA y el exceso de simetría.
Toma como referencia los detalles de los portafolios que subí.

Secciones.
1. Presentación con mi nombre y lo que hago en una línea
2. Sobre mí
3. Proyectos destacados, con espacio para imagen y descripción
4. Experiencia
5. Contacto

Cuando termines, explícame qué decisiones de diseño tomaste.
```

## Paso 2. Mejora el diseño

Revisa la primera versión y di qué falta. Estos pedidos suelen ayudar.

```text
Revisa la página como lo haría un diseñador senior.
Califícala del 1 al 10 en tipografía, color, espaciado y jerarquía, y luego mejora lo que tenga menos puntaje.
No uses el azul corporativo genérico ni las fuentes por defecto.
```

## Paso 3. Agrega interacciones sutiles

```text
Agrega un efecto sutil al pasar el cursor sobre las tarjetas de proyecto, como un pequeño movimiento o un cambio de borde.
Cuando haga scroll a una sección, que el título aparezca de forma suave.
Nada llamativo, solo detalles cuidados.
```

## Paso 4. Convierte un proyecto en caso de estudio

```text
Toma el proyecto [nombre] y conviértelo en una página de caso de estudio.
Incluye el problema, la investigación, el proceso de diseño, las versiones, los retos, cómo se resolvieron y el resultado.
Usa solo los datos que te di. Si falta información, déjame espacios marcados para completarla.
```

## Paso 5. Publícala con Netlify

```text
Con el código de mi portafolio, usa mi conector de Netlify para crear un sitio nuevo y publicarlo.
Explícame cada paso como si nunca hubiera publicado una web.
Cuando esté en línea, dame la dirección y explícame cómo actualizarla después.
```

---

## Antes de compartir el enlace

1. Abre la página en tu celular y en tu computadora.
2. Revisa cada texto, fecha y enlace. Claude trabaja con lo que le diste y puede cometer errores.
3. Comprueba que no publicaste datos personales que no quieres que se vean, como tu teléfono o dirección.

## Límites honestos

- La primera versión casi nunca es la final. Llegar a un buen resultado toma varias rondas de cambios.
- Netlify es un servicio aparte, con sus propias cuentas, condiciones y planes.
- No necesitas programar para seguir estos pasos, pero sí revisar con cuidado lo que se publica.
- Si quieres un dominio propio, se configura aparte y puede tener costo.

## Fuentes

- Claude Academy, caso de uso Create a custom webpage. https://academy.claude.com/use-cases/create-a-custom-webpage. Consultado el 4 de noviembre de 2026.
