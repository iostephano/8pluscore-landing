# Guía de inicio en Claude Code

Creado por Stephano, @iOStephano, 8pluscore.com
Basado en el curso **Claude Code 101** de Anthropic, publicado en Claude Academy.

---

## Cómo usarlo

1. Revisa la parte 1 para elegir cómo quieres que Claude Code te pida permiso.
2. Sigue los prompts de la parte 2 en orden cada vez que empieces una tarea nueva.
3. Copia la plantilla de la parte 3 cuando tu proyecto ya tenga reglas que repites seguido.
4. Usa la parte 4 cuando una sesión se vuelva larga.

Reemplaza lo que está entre corchetes. Esta guía es para Claude Code, no para el chat de Claude.

---

## Parte 1. Modos de permiso

Con **Shift + Tab** cambias de modo durante la sesión.

| Modo | Qué hace | Cuándo usarlo |
|---|---|---|
| Manual | Pide permiso antes de editar un archivo o ejecutar un comando | Cuando estás empezando o el cambio es delicado |
| Aceptar ediciones | Edita archivos sin preguntar y sigue pidiendo permiso para la mayoría de comandos | Cuando ya revisaste el plan y confías en la dirección |
| Modo plan | Lee y explora, pero no edita tus archivos | Antes de escribir código, para armar el plan |
| Modo automático | Trabaja sin pedir permiso en cada paso, con una revisión de seguridad en segundo plano | Solo si entiendes el riesgo y revisas el resultado |

El modo con el que empieza cada sesión depende de tu versión y tu configuración. Mientras más libertad le das, más difícil es detectar un error antes de que pase.

---

## Parte 2. Un prompt para cada paso del flujo

El curso recomienda trabajar en 4 pasos: explorar, planificar, programar y guardar los cambios.

### Paso 1. Explorar
```
Antes de cambiar nada, revisa el proyecto y explícame:
1. Cómo está organizado.
2. Qué partes tienen relación con [funcionalidad o problema].
3. Qué dependencias o riesgos ves para trabajar en eso.
No edites ningún archivo.
```

### Paso 2. Planificar
Activa el modo plan con Shift + Tab y escribe:
```
Necesito [lo que quieres lograr].
Arma un plan que diga:
1. Qué archivos vas a cambiar y por qué.
2. Si hacen falta dependencias nuevas.
3. Cómo vamos a comprobar que funciona.
Si algo no está claro, pregúntame antes de proponer el plan.
```
Revisa el plan con calma. Este es el mejor momento para corregir el rumbo, porque todavía no hay código escrito.

### Paso 3. Programar
```
Aprobado. Sigue el plan.
El trabajo está terminado cuando [criterio concreto, por ejemplo, todas las pruebas pasan y la pantalla muestra X].
Si encuentras algo que el plan no consideró, detente y avísame antes de cambiar el enfoque.
```
Si tu proyecto tiene pruebas, asegúrate de que sean confiables antes de usarlas como criterio.

### Paso 4. Revisar y guardar los cambios
```
Usa un subagente para revisar los cambios de esta sesión. Que busque errores, casos que no se consideraron y código innecesario. Dame la lista antes de corregir nada.
```
Después de revisar tú también:
```
Escribe el mensaje de commit para estos cambios, con el mismo estilo de los commits anteriores del proyecto.
```

---

## Parte 3. Plantilla de CLAUDE.md

CLAUDE.md es un archivo que Claude Code lee al iniciar cada sesión. Va en la raíz de tu proyecto y le da el contexto que de otra forma tendría que descubrir cada vez.

Consejos del curso:
- Empieza sin CLAUDE.md y anota lo que tienes que corregir seguido. Eso es lo que va en el archivo.
- Cuando quieras uno, el comando `/init` genera una primera versión a partir de tu proyecto.
- Si corriges a Claude en algo que se repite, pídele que guarde esa regla en CLAUDE.md.
- Para que lea un documento del proyecto, usa `@` con la ruta, por ejemplo `@README.md`.
- El CLAUDE.md del proyecto se comparte con tu equipo. Tus preferencias personales van en tu CLAUDE.md de usuario, que aplica a todos tus proyectos.

```markdown
# Proyecto
[Qué es el proyecto en 1 o 2 líneas, y con qué lenguaje, framework y herramientas está hecho.]

# Comandos
- Compilar o ejecutar: `[comando]`
- Pruebas: `[comando]`
- Revisión de estilo: `[comando]`

# Estilo de código
- [Regla 1, por ejemplo, nombres de archivos y carpetas]
- [Regla 2, por ejemplo, cómo se organizan las capas]
- [Regla 3, por ejemplo, qué patrón usar y cuál evitar]

# Reglas importantes
- [Algo que Claude debe hacer siempre]
- [Algo que Claude nunca debe hacer, por ejemplo, tocar una carpeta concreta]

# Documentación
- Si necesitas más contexto, lee @README.md
```

Mantenlo corto. Solo lo que Claude necesita y no puede deducir rápido del proyecto.

---

## Parte 4. Controlar el contexto en sesiones largas

El contexto es todo lo que Claude Code tiene presente en la sesión. Cada archivo que lee, cada comando y cada mensaje ocupan espacio, y ese espacio tiene un límite.

| Comando | Qué hace | Cuándo usarlo |
|---|---|---|
| `/context` | Muestra cuánto contexto usas y qué lo ocupa | Cuando sientes que la sesión se volvió pesada |
| `/compact` | Resume la sesión y libera espacio, pero puede perder detalles | Cuando sigues en la misma tarea y necesitas continuar |
| `/clear` | Borra la sesión y empieza de cero | Cuando terminas una tarea y empiezas otra |

Más consejos del curso:
- Sé específico. Un prompt vago obliga a Claude a explorar más, y eso gasta más contexto.
- Desactiva los servidores MCP que no tienen relación con el proyecto.
- Usa un subagente cuando solo necesitas una respuesta, como dónde está una parte del código, y no todo el recorrido.

---

## Límite honesto

Claude Code se puede equivocar. Puede entender mal lo que pides, introducir un error nuevo o hacer una solución más complicada de lo necesario. Esta guía reduce esos riesgos, pero no los elimina. Revisa cada cambio antes de guardarlo. Los modos, comandos y menús pueden cambiar con nuevas versiones, así que confirma en la documentación oficial si algo no aparece igual.

---

## Fuentes

Consultadas el 4 de noviembre de 2026.
- Anthropic, curso Claude Code 101, Claude Academy. https://academy.claude.com/courses/claude-code-101
- Lección How Claude Code works. https://academy.claude.com/courses/claude-code-101/how-claude-code-works
- Lección The explore → plan → code → commit workflow. https://academy.claude.com/courses/claude-code-101/the-explore-plan-code-commit-workflow
- Lección Context management. https://academy.claude.com/courses/claude-code-101/context-management
- Lección The CLAUDE.md file. https://academy.claude.com/courses/claude-code-101/the-claude-md-file
