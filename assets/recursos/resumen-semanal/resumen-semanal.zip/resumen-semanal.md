# Kit: Tu resumen semanal con Claude

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el webinar **Building your first workflow with Cowork** de Anthropic, del equipo de Customer Success, y en el artículo oficial de ayuda sobre tareas programadas.
Producto: Claude, en la experiencia que une chat y Cowork, o en Cowork si todavía lo ves por separado.

---

## Qué es este kit

Una guía en español para armar un resumen semanal que junta tus prioridades, tu calendario y tus novedades, y para dejarlo programado cada semana. Trae el prompt, una lista para revisar permisos y los pasos para programarlo.

## Antes de empezar

- Las tareas programadas están en los planes de pago de Claude. En Team y Enterprise depende de lo que active tu administrador.
- Anthropic está uniendo el chat y Cowork en una sola experiencia. Si en tu caja de mensajes ya no ves Chat y Cowork por separado, tienes la versión nueva y algunos pasos se ven distintos.
- Conecta antes las apps que vas a usar, por ejemplo tu calendario y tu correo, desde los conectores.

---

## Paso 1. Escribe tus prioridades

Crea un documento corto con tus 3 a 5 prioridades del mes. Claude lo usa para decidir qué es importante en tu semana.

```text
Mis prioridades de este mes
1. [Prioridad 1]
2. [Prioridad 2]
3. [Prioridad 3]
Lo que no es prioridad este mes: [tema que puede esperar]
```

## Paso 2. Pide el primer resumen a mano

Antes de programarlo, pruébalo una vez y corrige lo que no te sirva.

```text
Prepárame mi resumen de la semana.
1. Lee mis prioridades del documento [nombre del documento].
2. Revisa mi calendario de los próximos 7 días y marca las reuniones que se relacionan con cada prioridad.
3. Revisa los correos de los últimos 7 días y separa los que necesitan respuesta mía de los que son solo informativos.
4. Dime qué prioridad no tiene tiempo reservado esta semana.
5. Termina con 3 acciones concretas para el lunes.
Usa títulos cortos y listas. No envíes ni respondas ningún correo, solo léelos.
```

## Paso 3. Ajusta el formato

```text
Haz el resumen más corto. Máximo una pantalla.
Pon primero lo que vence esta semana.
Si algo no lo pudiste revisar, dímelo al final en vez de suponerlo.
```

## Paso 4. Revisa los permisos antes de aprobar

Cuando Claude pida un permiso, revisa estos puntos.

- [ ] Sé qué app quiere usar y para qué.
- [ ] El permiso es para leer y no para enviar, borrar o publicar.
- [ ] La tarea no necesita datos que no quiero compartir.
- [ ] Si es una tarea programada, sé que va a correr sin que yo esté mirando.
- [ ] Las acciones que nunca quiero sin mi aprobación quedan bloqueadas o con aprobación.

## Paso 5. Programa el resumen

**En la experiencia nueva**
1. En cualquier conversación, escribe la tarea y cada cuánto quieres que corra.

```text
Programa este resumen para que corra cada lunes a las 8 de la mañana, con las mismas instrucciones del resumen que acabamos de ajustar.
```

2. Responde las preguntas de Claude.
3. Revisa el nombre, el horario y las instrucciones que propone.
4. Haz clic en Schedule.

**En Cowork, si todavía lo ves por separado**
1. Haz clic en Scheduled, en la barra lateral.
2. Haz clic en New task y elige Create with Claude.
3. Responde las preguntas, revisa la tarea y haz clic en Schedule.

Desde Scheduled puedes editar, pausar, reanudar, borrar o correr la tarea cuando quieras.

---

## Límites

- Cada ejecución es una sesión propia. Revisa el resumen antes de actuar con él.
- Las tareas corren en remoto y siguen su horario aunque tu computadora esté apagada. Las que necesitan archivos o apps de tu computadora solo corren en tu equipo.
- Claude solo ve lo que conectas. Si tu calendario o tu correo no están conectados, el resumen sale incompleto.
- Los nombres de los botones pueden cambiar mientras Anthropic une chat y Cowork.

## Fuentes

- Anthropic, webinar Building your first workflow with Cowork. https://claude.com/resources/webinars/recurring-building-your-first-workflow-with-cowork. Consultado el 4 de noviembre de 2026.
- Centro de ayuda de Claude, Schedule recurring tasks in Claude Cowork. https://support.claude.com/en/articles/13854387-schedule-recurring-tasks-in-claude-cowork. Consultado el 4 de noviembre de 2026.
