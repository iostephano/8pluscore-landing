# Guía para delegarle trabajo a Claude

Creado por Stephano, @iOStephano, 8pluscore.com
Basado en el curso **Introduction to Claude Cowork** de Anthropic, publicado en Claude Academy.

---

## Cómo usarlo

1. Antes de tu primera tarea, revisa la lista de seguridad de la parte 1.
2. Escribe tus instrucciones fijas con la plantilla de la parte 2. Se hace una sola vez.
3. Para cada tarea, usa la plantilla de pedido de la parte 3.
4. Cuando recibas el resultado, revísalo con la lista de la parte 4.

Según tu versión de la app de Claude, esta forma de trabajar aparece en su propia pestaña, llamada Cowork, o la pides en una conversación normal. Para trabajar con archivos de tu computadora, usa la app de escritorio. Reemplaza lo que está entre corchetes.

---

## Parte 1. Lista de seguridad antes de empezar

- [ ] Creé una carpeta solo para esta tarea y copié ahí lo que hace falta. No le doy acceso a Documentos, Descargas o el Escritorio completos.
- [ ] Tengo una copia de los archivos que no podría recuperar, en un lugar donde Claude no tiene acceso.
- [ ] Si es una tarea programada o un flujo nuevo, la primera vez la pruebo con una copia de los datos.
- [ ] Dejé activo el modo en que Claude me pregunta antes de enviar, publicar o compartir algo.
- [ ] Solo activé las conexiones que esta tarea necesita.
- [ ] En mi pedido dejé claro qué puede cambiar y qué no, sobre todo si uso palabras como borrar, quitar, reemplazar o actualizar.

Claude siempre pregunta antes de borrar un archivo de forma permanente. Aun así, lee cada confirmación antes de aceptarla.

---

## Parte 2. Instrucciones fijas

Se guardan en la configuración de Claude, en la sección de instrucciones, y Claude las tiene en cuenta en cada sesión. Empieza corto y agrega lo que te veas corrigiendo seguido.

```
Soy [rol] en [empresa o negocio] y trabajo en [1 o 2 temas principales].
Estas son siglas y nombres internos que uso: [lista con su significado].
La mayoría de lo que entrego son [documentos, presentaciones, hojas de cálculo, correos].
Prefiero respuestas breves, con la conclusión primero y el contexto en un solo párrafo.
Escribe siempre en español.
Antes de crear el archivo final, muéstrame un borrador para revisarlo.
```

---

## Parte 3. Plantilla de pedido

Un buen pedido dice 3 cosas. Qué quieres recibir, de dónde sale la información y qué detalles solo conoces tú.

### Primer pedido para probar
```
Revisa todo lo que hay en esta carpeta y escríbeme un resumen breve de qué contiene, cómo se relacionan los documentos y qué información te parece importante que yo sepa.
No modifiques ningún archivo.
```
Compara el resumen con lo que tú ya sabes de esos archivos.

### Plantilla para cualquier tarea
```
Quiero recibir: [entregable concreto, con formato y extensión, por ejemplo, un resumen de 1 página en Word].

Usa esta información: [carpeta, apps conectadas, canales, rango de fechas].

Ten en cuenta: [detalles que solo tú conoces, por ejemplo, para quién es, qué decisión se tomó antes o qué no debe aparecer].

Límites: [qué no debe hacer, por ejemplo, no enviar nada, solo borradores, o solo los 3 archivos más recientes].

Antes de empezar, muéstrame tu plan y pregúntame lo que no esté claro.
```

### Para corregir mientras trabaja
Si ves que va por mal camino, no esperes a que termine.
```
Detente. [Qué está mal, por ejemplo, la fuente, el formato o el tono]. Usa [lo correcto] y sigue desde donde ibas.
```

---

## Parte 4. Revisar el resultado

- ¿Cumple el objetivo que pediste o es algo parecido, pero distinto?
- ¿Las cifras y los datos son correctos? Pídele que te diga de qué documentos sacó cada dato y revísalos tú.
- ¿Hay fechas, nombres o frases que no puedes encontrar en tus archivos? Eso es una alerta.
- Si está casi bien, dile qué cambiar en vez de pedirle que empiece de cero.
- Si está mal en algo importante, probablemente faltó contexto en el pedido. Dale ese contexto y pídele que lo ajuste.

```
Dime de qué archivos o fuentes sacaste cada dato de este documento, para poder revisarlos.
```

---

## Límite honesto

Delegar una tarea no es delegar tu criterio. Claude puede equivocarse, entender mal el pedido o usar una fuente que no esperabas, por eso revisa cada resultado antes de usarlo o enviarlo. El curso recomienda no usarlo para flujos regulados que necesitan registro de auditoría, para datos personales muy sensibles sin aprobación de tu equipo de TI, ni para enviar o publicar algo importante sin revisarlo. Los nombres de menús y funciones cambian según la versión de la app y tu plan, así que confirma en el centro de ayuda si algo no aparece igual.

---

## Fuentes

Consultadas el 4 de noviembre de 2026.
- Anthropic, curso Introduction to Claude Cowork, Claude Academy. https://academy.claude.com/courses/introduction-to-claude-cowork
- Lección What is Claude Cowork. https://academy.claude.com/courses/introduction-to-claude-cowork/what-is-cowork
- Lección Setting up Claude Cowork. https://academy.claude.com/courses/introduction-to-claude-cowork/getting-set-up
- Lección Hand Claude Cowork your first task. https://academy.claude.com/courses/introduction-to-claude-cowork/the-task-loop
- Lección Standing context: Global instructions and projects. https://academy.claude.com/courses/introduction-to-claude-cowork/giving-cowork-context
- Lección Best practices for working safely. https://academy.claude.com/courses/introduction-to-claude-cowork/permissions-usage-choosing-your-model
