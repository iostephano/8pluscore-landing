# Kit: Que Claude escriba con tu voz

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el caso de uso **Write in my voice** de Claude Academy, de Anthropic.
Producto: Claude Cowork.

---

## Qué es este kit

Un conjunto de prompts en español para que Claude lea cómo escribes, describa tu estilo y lo guarde como una skill llamada `/mi-voz`. Desde ahí, los borradores que te prepare parten de tu forma de escribir y no de un tono genérico.

## Antes de empezar

1. Abre Claude Cowork y crea un proyecto, por ejemplo **Mi voz**. Así el perfil y tus correcciones quedan juntos.
2. Elige de dónde leerá Claude tus textos.
   - **Opción A.** Conecta tu correo y tu herramienta de mensajes desde los conectores de Cowork.
   - **Opción B.** Si prefieres no conectar nada, crea una carpeta llamada `Muestras-de-escritura` con correos enviados, mensajes y documentos tuyos, y apunta Cowork a esa carpeta.
3. Usa textos reales, no solo los mejores. El perfil sale mejor cuando refleja cómo escribes de verdad.

---

## Paso 1. Primer análisis de tu estilo

```text
Lee los mensajes que he enviado y descríbeme mi tono y mi estilo de escritura.
Para cada hábito que detectes, muéstrame 1 o 2 ejemplos reales como evidencia.
Revisa en especial cómo abro y cierro los mensajes, el largo de mis frases, las palabras que repito y cómo me despido.
Marca con claridad lo que no tengas seguro en vez de suponerlo.
```

## Paso 2. Corrige lo que no te representa

```text
Corrige estos puntos del análisis.
1. [Lo que dijo y no es cierto]
2. [Un hábito que te falta mencionar]
3. [Una palabra o frase que nunca usarías]
Cuando lo tengas corregido, muéstrame el perfil final antes de guardarlo.
```

## Paso 3. Guarda el perfil como skill

```text
Guarda este perfil corregido como una skill llamada /mi-voz.
Incluye las reglas de estilo, las palabras que uso y las que evito, y 3 textos míos como ejemplos de referencia.
Quiero que uses /mi-voz cada vez que me prepares un borrador de correo, mensaje o publicación.
```

## Paso 4. Mejora la skill cada vez que edites un borrador

Cada vez que cambies algo de un borrador porque "así no lo diría", díselo a Claude.

```text
Actualiza /mi-voz con lo que cambié en este borrador.
[Describe los cambios. Por ejemplo, nunca empiezo con "Espero que estés bien", voy directo al pedido y después doy el contexto, y firmo solo con mi nombre.]
Guarda estos cambios como reglas y agrega este borrador editado a los ejemplos.
```

Atajo. Al terminar de corregir cualquier borrador, escribe **"agrega eso a /mi-voz"**.

## Paso 5. Actualiza el perfil cada mes

Tu forma de escribir cambia con tu trabajo. Puedes pedir una tarea programada.

```text
Crea una tarea programada para el primer domingo de cada mes a las 6 pm.
Lee mis correos y mensajes enviados de los últimos 90 días y actualiza /mi-voz con lo nuevo.
Mantén intactas todas las reglas que agregué a mano.
```

---

## Cómo saber si funciona

- Pide un borrador de algo que escribes seguido y compáralo con uno tuyo.
- Si sigue sonando genérico, revisa que la skill tenga ejemplos reales y reglas concretas, no solo adjetivos como "cercano" o "profesional".

## Límites honestos

- El primer perfil es una foto de un momento. Mejora con tus correcciones, no de una sola vez.
- Claude solo lee lo que tú conectas o pones en la carpeta. Revisa qué permisos das y qué textos compartes, sobre todo si hay información de clientes.
- Los conectores, las tareas programadas y la opción de compartir skills dependen de tu plan y, en empresas, de lo que permita el administrador.
- Revisa siempre el borrador antes de enviarlo. La skill ayuda con el estilo, pero el contenido sigue siendo tu responsabilidad.

## Fuentes

- Claude Academy, caso de uso Write in my voice. https://academy.claude.com/use-cases/my-voice. Consultado el 4 de noviembre de 2026.
