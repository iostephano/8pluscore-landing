# Subagente revisor de código para Claude Code

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el curso "Introduction to subagents" de Claude Academy, de Anthropic.

Este archivo trae un subagente listo para usar. Se llama `revisor-codigo` y revisa los cambios recientes de tu código para encontrar problemas de calidad y seguridad. Sigue las 4 reglas del curso. Tiene una descripción clara, un formato de respuesta, una sección de obstáculos y solo las herramientas que necesita, sin permiso para editar.

## Qué necesitas

- Claude Code instalado. Este subagente es para Claude Code en la terminal, no para el chat de Claude.
- Un proyecto con Git.

## Qué es un subagente

Es un asistente que trabaja en su propia conversación, con sus propias instrucciones. Lee archivos, busca y analiza aparte, y a tu conversación principal solo le devuelve un resumen. Así tu conversación no se llena con todo el trabajo intermedio.

## Paso 1. Elige dónde guardarlo

```
tu usuario/
└── .claude/
    └── agents/                 ← para todos tus proyectos
        └── revisor-codigo.md

tu proyecto/
└── .claude/
    └── agents/                 ← solo para este proyecto
        └── revisor-codigo.md
```

- En `~/.claude/agents/` sirve para todos los proyectos de tu computadora.
- En `.claude/agents/` dentro de un proyecto, sirve solo para ese proyecto.

La carpeta `.claude` está oculta. En Mac, en Finder presiona Comando + Mayúsculas + punto para verla. Si la carpeta `agents` no existe, créala.

Desde la terminal, en macOS o Linux:

```bash
mkdir -p ~/.claude/agents
```

## Paso 2. Crea el archivo revisor-codigo.md

Dentro de la carpeta `agents`, crea un archivo llamado `revisor-codigo.md` y pega esto:

```markdown
---
name: revisor-codigo
description: Úsalo para revisar código escrito o modificado recientemente y encontrar problemas de calidad, seguridad y buenas prácticas. Debes indicarle con precisión qué archivos quieres que revise.
tools: Bash, Glob, Grep, Read
model: sonnet
color: purple
---

Eres un revisor de código. Tu trabajo es examinar el código escrito o modificado recientemente y encontrar problemas que afecten la confiabilidad, la seguridad, el mantenimiento o el rendimiento.

Cómo trabajar:
1. Si no te indicaron archivos, ejecuta `git diff` para ver los cambios pendientes.
2. Lee los archivos modificados y el contexto necesario para entenderlos.
3. No edites ningún archivo. Solo revisa y reporta.

Entrega tu revisión en español con este formato:

## Resumen
Qué revisaste y tu evaluación general, en 2 o 3 frases.

## Problemas críticos
Vulnerabilidades de seguridad, riesgos para los datos o errores de lógica que se deben corregir ya. Indica archivo y línea.

## Problemas importantes
Problemas de calidad, de arquitectura o de rendimiento.

## Problemas menores
Estilo, documentación faltante o mejoras pequeñas.

## Recomendaciones
Sugerencias de mejora o refactorización.

## Obstáculos encontrados
Problemas de configuración, soluciones que tuviste que buscar, comandos que necesitaron opciones especiales o dependencias que dieron problemas. Si no hubo, escribe "Ninguno".

## Estado
Di con claridad si el código está listo para integrarse o si necesita cambios.
```

Cómo se lee el archivo:

- `name` es el nombre del subagente. También puedes llamarlo con `@agent-revisor-codigo` en tu mensaje.
- `description` decide cuándo Claude lo usa y qué le pide. Debe ir en una sola línea.
- `tools` son las herramientas que puede usar. No tiene permiso para editar ni escribir archivos.
- `model` es el modelo que usa. Puede ser `haiku`, `sonnet`, `opus`, `fable` o `inherit`, que usa el mismo modelo de tu conversación.
- `color` es el color con el que lo ves en pantalla.
- Debajo de la segunda línea `---` van las instrucciones del subagente.

## Paso 3. Pruébalo

Si la carpeta `agents` no existía al abrir la sesión, reinicia Claude Code. Luego haz cambios en tu código y escribe:

> Usa el subagente revisor-codigo para revisar mis cambios en [nombre del archivo].

Si quieres que Claude lo use sin que se lo pidas, agrega la palabra "proactivamente" en la descripción. Por ejemplo, "Úsalo proactivamente después de cambios grandes en el código."

## Cuándo usar un subagente

Úsalo para:
- Investigar o explorar un proyecto cuando solo necesitas la respuesta.
- Revisar código, porque lo ve sin el historial de cómo se escribió.
- Tareas que necesitan instrucciones propias, como redactar textos de marketing.

Evítalo para:
- Subagentes que solo dicen "eres experto en algo". Claude ya tiene ese conocimiento.
- Cadenas de pasos donde cada paso depende de lo que encontró el anterior.
- Correr pruebas, porque te devuelve un resumen y pierdes el detalle de los errores.

La pregunta clave es si te importa el trabajo intermedio. Si no te importa, delégalo.

## Límite

Tu conversación principal no ve cómo el subagente llegó a su respuesta, solo el resumen. Si no se activa cuando esperas, revisa la descripción y agrega ejemplos de cuándo usarlo.

## Fuentes consultadas el 4 nov 2026

- Claude Academy, Introduction to subagents
  https://academy.claude.com/courses/introduction-to-subagents
- Lección What are subagents?
  https://academy.claude.com/courses/introduction-to-subagents/what-are-subagents
- Lección Creating a subagent
  https://academy.claude.com/courses/introduction-to-subagents/creating-a-subagent
- Lección Designing effective subagents
  https://academy.claude.com/courses/introduction-to-subagents/designing-effective-subagents
- Lección Using subagents effectively
  https://academy.claude.com/courses/introduction-to-subagents/using-subagents-effectively
