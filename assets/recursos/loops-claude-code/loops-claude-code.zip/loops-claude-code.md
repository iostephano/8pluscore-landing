# Kit: Recetas de loops en Claude Code

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el webinar **Startup Builds: Getting Started with Loops** de Anthropic, presentado por Mark Nowicki, y en el artículo oficial **Loop engineering: Getting started with loops** del equipo de Claude Code.
Producto: Claude Code, en la terminal.

---

## Qué es este kit

Una guía en español para elegir el tipo de loop correcto en Claude Code, con recetas para copiar y una lista de seguridad para que el loop termine cuando debe y no gaste de más.

Un loop es Claude repitiendo un ciclo de trabajo hasta que se cumple una condición para detenerse.

## Antes de empezar

- Esto es para Claude Code. No aplica al chat de Claude.
- Empieza por lo más simple. Muchas tareas no necesitan un loop.
- Algunas funciones, como `/schedule`, los flujos dinámicos y el modo auto, aparecen como vista previa en la documentación. Pueden cambiar o no estar en tu plan.

---

## Los 4 tipos de loop

| Loop | Qué le entregas a Claude | Cuándo usarlo | Con qué |
|---|---|---|---|
| Por turnos | La revisión | Estás explorando o decidiendo | Un prompt y una skill que verifique |
| Por meta | La condición para terminar | Sabes cómo se ve "terminado" | `/goal` |
| Por tiempo | El momento en que arranca | El trabajo llega cada cierto tiempo | `/loop` o `/schedule` |
| Proactivo | El prompt completo | El trabajo se repite y está bien definido | Todo lo anterior junto |

## Cómo elegir

1. Busca una tarea donde tú seas el cuello de botella.
2. Pregúntate 3 cosas.
   - ¿Puedo escribir cómo se revisa que quedó bien?
   - ¿Tengo claro cómo se ve terminado?
   - ¿El trabajo llega con un horario?
3. Si solo respondes sí a la primera, usa un loop por turnos con una skill de verificación.
4. Si respondes sí a la segunda, usa `/goal`.
5. Si respondes sí a la tercera, usa `/loop` o `/schedule`.

---

## Receta 1. Loop por meta con límite de intentos

`/goal` hace que Claude siga trabajando hasta cumplir tu condición. Otro modelo revisa la condición cada vez que Claude intenta parar.

```text
/goal todas las pruebas de la carpeta tests pasan. Detente después de 5 intentos.
```

```text
/goal el puntaje de Lighthouse de la página principal llega a 90 o más. Detente después de 5 intentos.
```

Reglas para escribir la meta.
- Usa una condición que se pueda medir, como pruebas que pasan o un puntaje.
- El revisor solo lee lo que aparece en la conversación. Pide que Claude muestre el resultado de las pruebas.
- Pon siempre un máximo de intentos.
- Para cancelar, usa `/goal clear`.
- Para ver turnos y tokens usados, escribe `/goal` sin nada más.

## Receta 2. Loop por tiempo en tu computadora

`/loop` repite un prompt cada cierto intervalo. Corre en tu computadora, así que se detiene si la apagas.

```text
/loop 10m revisa mi PR, responde los comentarios de revisión y corrige el CI si falla. Avísame cuando el PR se apruebe.
```

```text
/loop 30m revisa si terminó el despliegue. Si falla, dime en qué paso y por qué.
```

Reglas.
- Usa intervalos largos. Cada vuelta envía tu contexto otra vez.
- Un loop con intervalo fijo sigue hasta que lo canceles o pasen 7 días.
- Para un loop que espera su siguiente vuelta, presiona `Esc` para detenerlo.

## Receta 3. Loop por tiempo en la nube

`/schedule` crea una rutina que corre en la infraestructura de Anthropic, aunque tu computadora esté apagada.

```text
/schedule cada lunes a las 9: revisa las dependencias del proyecto, lista las que tienen versión nueva y abre un PR solo con las actualizaciones menores.
```

## Receta 4. Skill de verificación para el loop por turnos

Guarda tus pasos de revisión en una skill para que Claude revise su propio trabajo antes de entregártelo. Crea el archivo `.claude/skills/verificar-cambios/SKILL.md` en tu proyecto.

```markdown
---
name: verificar-cambios
description: Usar después de cualquier cambio en la interfaz, antes de dar la tarea por terminada.
---

1. Inicia el servidor de desarrollo.
2. Abre la pantalla que cambiaste y prueba la acción nueva.
3. Revisa que no haya errores en la consola.
4. Corre las pruebas del proyecto.
5. Si un paso falla, corrige y vuelve a empezar desde el paso 1.
6. No entregues el trabajo con pasos sin revisar.
```

---

## Lista de seguridad antes de dejar un loop corriendo

- [ ] La condición para terminar es específica y se puede medir.
- [ ] Hay un máximo de intentos o un intervalo largo.
- [ ] El loop que escribe código tiene otro paso o agente que lo revisa.
- [ ] Probé el loop una vez antes de dejarlo solo.
- [ ] Sé cómo detenerlo, con `/goal clear`, `Esc` o cancelando la rutina.
- [ ] Revisé el consumo con `/usage` después de las primeras vueltas.
- [ ] Las tareas repetitivas usan un modelo más pequeño y las decisiones difíciles el más capaz.

## Límites

- Una meta vaga hace que el loop termine antes de tiempo o que no termine nunca.
- El costo sube con la frecuencia, el modelo y la cantidad de agentes.
- Un loop no reemplaza tu revisión. Revisa el resultado antes de usarlo, sobre todo si cambia código en producción.
- Las recetas son ejemplos propios. Ajusta los nombres de carpetas, comandos e intervalos a tu proyecto.

## Fuentes

- Anthropic, webinar Startup Builds: Getting Started with Loops. https://claude.com/resources/webinars/startup-builds-getting-started-with-loops. Consultado el 4 de noviembre de 2026.
- Anthropic, Loop engineering: Getting started with loops, 30 de junio de 2026. https://claude.com/resources/articles/getting-started-with-loops. Consultado el 4 de noviembre de 2026.
- Claude Academy, lección Steering long sessions del curso Claude Code in action. https://academy.claude.com/courses/claude-code-in-action/steering-long-sessions. Consultado el 4 de noviembre de 2026.
