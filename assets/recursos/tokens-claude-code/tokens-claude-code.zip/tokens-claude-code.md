# Kit: Gasta menos tokens en Claude Code

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el webinar **Maximizing Value from Claude Code** de Anthropic, presentado por Lydia Hallie, y en la documentación oficial de Claude Code sobre costos.
Producto: Claude Code, en la terminal.

---

## Qué es este kit

Una guía en español con los comandos y hábitos que ayudan a que una sesión de Claude Code gaste menos tokens sin perder calidad. Trae una tabla de qué comando usar en cada momento, una limpieza de 10 minutos para tu proyecto y prompts listos para copiar.

## Antes de empezar

- Esto es para Claude Code en la terminal o en su extensión de VS Code. No aplica al chat de Claude.
- Claude Code envía toda la conversación en cada mensaje. Por eso una sesión larga cuesta más aunque tu pregunta sea corta.
- Revisa tu consumo con `/usage`. Si tienes plan Pro o Max, el monto en dólares de la sesión es una referencia y no tu factura. Ahí verás también las barras de tu plan.

---

## 1. Elige modelo y esfuerzo con una sola pregunta

Cuando el resultado no es el que esperabas, pregúntate qué pasó.

| Lo que viste | Qué cambiar |
|---|---|
| No sabía lo suficiente sobre el tema | Sube de modelo con `/model` |
| Sabía, pero se detuvo antes de terminar | Sube el esfuerzo con `/effort` |
| Hizo más de lo que pediste | Baja el esfuerzo un nivel |

Empieza siempre en el esfuerzo por defecto y mueve un nivel a la vez.

## 2. Qué comando usar en cada momento

| Momento | Comando | Qué hace |
|---|---|---|
| Terminaste una tarea y empiezas otra distinta | `/rename nombre` y luego `/clear` | Guarda el nombre de la sesión y empieza de cero. `/clear` no cuesta nada |
| Sigues en la misma tarea, pero la conversación está muy larga | `/compact` con instrucciones | Resume la conversación y guarda lo que le pidas |
| Claude tomó un camino equivocado | `Esc` dos veces o `/rewind` | Vuelve a un punto anterior de la conversación, del código o de ambos |
| Quieres volver a una sesión guardada | `/resume` | Abre una sesión anterior |

`/compact` sí cuesta, porque lee toda la conversación para resumirla. Si no necesitas continuidad, usa `/clear`.

### Ejemplos de `/compact` con instrucciones

```text
/compact Conserva solo los cambios de la API, los archivos modificados y lo que falta por hacer.
```

```text
/compact Conserva los resultados de las pruebas y las decisiones de diseño. Descarta la depuración que ya terminó.
```

## 3. Cuida el caché

Claude Code reutiliza la parte de la conversación que ya envió, y eso cuesta mucho menos. Algunos cambios obligan a enviarla completa otra vez.

- Cambiar de modelo a mitad de la sesión.
- Cambiar el nivel de esfuerzo.
- Activar o desactivar el modo rápido.
- Volver después de una pausa larga.

Mi recomendación es hacer esos cambios al empezar una tarea nueva, justo después de `/clear`, y no a mitad de un trabajo largo.

## 4. Mantén el contexto liviano

- Pide tareas concretas. "Agrega validación a la función de login en auth.ts" gasta menos que "mejora el código".
- Cuando un comando devuelve mucho texto, como pruebas o registros, pídele a un subagente que lo corra y te traiga solo el resumen.
- Para tareas complejas, usa el modo plan con `Shift + Tab` antes de que Claude edite. Corregir un plan es más barato que corregir código.

### Prompt para delegar una tarea ruidosa

```text
Usa un subagente para correr todas las pruebas del proyecto.
Tráeme solo las pruebas que fallan, el archivo donde fallan y el error en una línea.
No me muestres la salida completa.
```

## 5. La limpieza de 10 minutos

Hazla una vez por proyecto. Lo que quites deja de costar en todas las sesiones siguientes.

1. Corre `/context` y mira cuánto ocupa cada cosa al iniciar.
2. Corre `/mcp` y desactiva los servidores que no usas en este proyecto.
3. Abre tu CLAUDE.md. La documentación recomienda menos de 200 líneas.
4. Si tu CLAUDE.md tiene instrucciones para tareas puntuales, como revisar PR o hacer migraciones, pásalas a una skill. Las skills solo se cargan cuando se usan.
5. Corre `/usage` y revisa si te recomienda algún cambio.

### Prompt para revisar tu CLAUDE.md

```text
Revisa mi CLAUDE.md.
Marca qué instrucciones aplican a todas las tareas y cuáles solo a tareas puntuales.
Propón qué mover a skills y cómo quedaría un CLAUDE.md de menos de 200 líneas.
Muéstrame el cambio antes de editar el archivo.
```

---

## Lista rápida para cada sesión

- [ ] Empecé con una tarea concreta.
- [ ] Elegí modelo y esfuerzo antes de empezar, no a mitad.
- [ ] Usé `/clear` al cambiar de tema.
- [ ] Usé `/compact` con instrucciones cuando la sesión se alargó.
- [ ] Delegué a un subagente lo que devuelve mucho texto.
- [ ] Revisé `/usage` al terminar.

## Límites

- Estos hábitos reducen el consumo, pero no hay una cifra fija de ahorro. Depende de tu proyecto y de cómo trabajas.
- Un `/compact` puede dejar fuera algo importante. Por eso conviene darle instrucciones.
- Los comandos y opciones de Claude Code cambian seguido. Si algo no aparece, revisa tu versión con `claude --version` y la documentación oficial.

## Fuentes

- Anthropic, webinar Maximizing Value from Claude Code. https://claude.com/resources/webinars/claude-code-maximizing-value. Consultado el 4 de noviembre de 2026.
- Documentación de Claude Code, Manage costs effectively. https://code.claude.com/docs/en/costs. Consultado el 4 de noviembre de 2026.
- Claude Academy, lección Steering long sessions del curso Claude Code in action. https://academy.claude.com/courses/claude-code-in-action/steering-long-sessions. Consultado el 4 de noviembre de 2026.
