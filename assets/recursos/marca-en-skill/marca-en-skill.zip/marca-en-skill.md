# Kit: Tu marca guardada en una skill de Claude

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el caso de uso **Package your brand guidelines in a skill** de Claude Academy, de Anthropic.
Producto: chat de Claude, en claude.ai.

---

## Qué es este kit

Una plantilla en español para guardar los colores, las tipografías y las reglas de tu marca en una skill. Así Claude las aplica cuando le pides una presentación, un documento o una hoja de cálculo, sin que tengas que repetirlas en cada chat.

## Antes de empezar

1. En la configuración de Claude, revisa que estén activadas la creación de archivos, la ejecución de código y las Skills.
2. Ten a mano tu manual de marca, si lo tienes. Puedes subirlo al chat o conectarlo desde Google Drive para que Claude lo use como referencia.

---

## Paso 1. Llena tu ficha de marca

Copia esta ficha y reemplaza lo que está entre corchetes.

```text
NOMBRE DE LA MARCA
[Nombre]

COLORES
Oscuro, [#000000], para texto principal y fondos oscuros
Claro, [#FFFFFF], para fondos claros y texto sobre fondo oscuro
Gris medio, [#000000], para elementos secundarios
Gris claro, [#000000], para fondos suaves
Acento 1, [#000000], para lo más importante
Acento 2, [#000000], acento secundario
Acento 3, [#000000], acento terciario

TIPOGRAFÍA
Títulos, [Fuente], en negrita
Texto, [Fuente], regular
Fuente de respaldo para títulos, [Arial u otra]
Fuente de respaldo para texto, [Georgia u otra]

REGLAS DE USO
Los títulos de diapositivas y documentos van con la fuente de títulos.
Los párrafos van con la fuente de texto.
Los acentos se usan en formas, gráficos y elementos visuales, alternándolos.
Sobre fondo claro, el texto va en el color oscuro.
Sobre fondo oscuro, el texto va en el color claro.
[Agrega cualquier otra regla, por ejemplo dónde va el logo o qué nunca se hace.]
```

## Paso 2. Pide a Claude que cree la skill

```text
Quiero crear una skill que aplique la identidad de mi marca a cualquier presentación, documento u hoja de cálculo que te pida.
Estos son los datos de mi marca.
[Pega aquí tu ficha de marca completa]
Crea la skill completa, con su archivo SKILL.md, una descripción clara de cuándo debe usarse y las instrucciones de cómo aplicar los colores y las tipografías.
Si tienes dudas sobre alguna regla, pregúntame antes de crearla.
```

## Paso 3. Instálala y pruébala

1. Guarda la skill que te entrega Claude en tu lista de skills.
2. Abre un chat nuevo y pide algo sin mencionar colores ni fuentes.

```text
Crea una presentación de 8 diapositivas con los resultados del trimestre, crecimiento de ventas, nuevos clientes y próximos pasos. Usa mi marca.
```

3. Revisa que los colores, las fuentes y los contrastes sean los correctos.

## Paso 4. Actualízala cuando tu marca cambie

```text
Actualiza mi skill de marca.
Las diapositivas de título van con fondo oscuro y texto claro, y las de contenido con fondo claro.
Los títulos pasan a 28 puntos.
Agrega el color [#000000] para [uso concreto].
```

## Paso 5. Combínala con otras skills

```text
Crea una presentación para el lanzamiento de mi nuevo producto.
Usa mi skill de marca para el diseño y mi skill [nombre de otra skill] para el contenido.
```

---

## Por qué la descripción importa

Claude primero lee solo el nombre y la descripción de cada skill. Si coinciden con lo que pides, recién ahí carga las instrucciones completas. Si la skill no se activa, revisa primero la descripción y escríbela con las palabras que usas al pedir.

## Límites honestos

- Las instrucciones dejan espacio a interpretación. Si necesitas que un color se aplique siempre igual, pide a Claude que agregue un script a la skill.
- Si Claude no tiene tu tipografía disponible, usará la fuente de respaldo. Revisa el resultado antes de enviarlo.
- La skill guarda reglas, no reemplaza el criterio de diseño. Revisa cada entrega importante.
- Las Skills y la creación de archivos dependen de tu plan y, en empresas, de lo que permita el administrador.

## Fuentes

- Claude Academy, caso de uso Package your brand guidelines in a skill. https://academy.claude.com/use-cases/package-your-brand-guidelines-in-a-skill. Consultado el 4 de noviembre de 2026.
