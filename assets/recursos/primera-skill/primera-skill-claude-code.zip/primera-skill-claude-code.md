# Tu primera skill en Claude Code

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el tutorial "Creating your first skill" de Claude Academy, de Anthropic.

Este archivo trae una skill lista para usar. Se llama `descripcion-pr` y escribe la descripción de un pull request siempre con el mismo formato. Funciona en todos tus proyectos.

## Qué necesitas

- Claude Code instalado. Esta skill es para Claude Code en la terminal, no para el chat de Claude. Claude Code está disponible en los planes de pago de Claude.
- Un proyecto con Git.

## Paso 1. Crea la carpeta

La estructura es esta:

```
tu usuario/
└── .claude/              ← la crea Claude Code
    └── skills/           ← la creas tú si no existe
        └── descripcion-pr/   ← una carpeta por skill
            └── SKILL.md
```

La carpeta `.claude` está oculta. En Mac, abre tu carpeta de usuario en Finder y presiona Comando + Mayúsculas + punto para ver las carpetas ocultas.

Para crear todo de una vez desde la terminal, en macOS o Linux:

```bash
mkdir -p ~/.claude/skills/descripcion-pr
```

En Windows, la ruta es `%USERPROFILE%\.claude\skills\descripcion-pr`.

## Paso 2. Crea el archivo SKILL.md

Dentro de esa carpeta, crea un archivo llamado exactamente `SKILL.md` y pega esto:

```markdown
---
name: descripcion-pr
description: Escribe descripciones de pull requests. Úsala cuando el usuario quiera crear un PR, escribir la descripción de un PR o resumir los cambios de una rama.
---

Cuando escribas la descripción de un PR:

1. Ejecuta `git diff main...HEAD` para ver todos los cambios de la rama.
2. Escribe la descripción en español con este formato:

## Qué
Una frase que explique qué hace este PR.

## Por qué
Contexto breve de por qué se necesita el cambio.

## Cambios
- Lista de los cambios concretos.
- Agrupa los cambios relacionados.
- Menciona los archivos eliminados o renombrados.
```

Si tu rama principal no se llama `main`, cámbiala en el paso 1 de las instrucciones. Por ejemplo, por `master` o `develop`.

Cómo se lee el archivo:

- `name` identifica la skill.
- `description` le dice a Claude cuándo usarla. Claude compara tu pedido con este texto.
- Todo lo que va debajo de la segunda línea `---` son las instrucciones que Claude sigue.

## Paso 3. Verifica que Claude la ve

Claude Code detecta las skills nuevas sin reiniciar. Si la carpeta `~/.claude/skills` no existía al abrir la sesión, escribe `/reload-skills`.

Luego pídele a Claude que liste las skills disponibles. Debe aparecer `descripcion-pr`.

## Paso 4. Pruébala

Haz cambios en una rama y escribe:

> Escribe la descripción del PR de mis cambios.

También puedes llamarla directamente con `/descripcion-pr`.

## Cómo decide Claude

- Al iniciar, Claude solo lee el nombre y la descripción de cada skill.
- Compara tu pedido con esas descripciones.
- Si coincide, lee el SKILL.md completo y sigue las instrucciones.

## Si dos skills se llaman igual

Gana la de mayor prioridad. El orden es empresa, personal y proyecto. Las skills de plugins no compiten porque llevan el nombre del plugin delante. Usa nombres claros, como `frontend-review` en vez de `review`.

## Editar o borrar

- Para cambiarla, edita el SKILL.md.
- Para borrarla, elimina su carpeta.

## Límite

Que se active depende de la descripción. Si Claude no la usa cuando esperas, reescribe la descripción con las palabras que tú usarías al pedir la tarea.

## Fuentes consultadas el 3 nov 2026

- Claude Academy, Creating your first skill
  https://academy.claude.com/tutorials/creating-your-first-skill
- Claude Academy, Introduction to agent skills, lección Creating your first skill
  https://academy.claude.com/courses/introduction-to-agent-skills/creating-your-first-skill
- Documentación de Claude Code, Skills
  https://code.claude.com/docs/en/skills
