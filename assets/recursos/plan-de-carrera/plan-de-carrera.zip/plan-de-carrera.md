# Kit: Arma tu plan de carrera con Claude

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el caso de uso **Plan your career path** de Claude Academy, de Anthropic.
Producto: chat de Claude, en claude.ai.

---

## Qué es este kit

Prompts en español para que Claude compare tu CV con los puestos que quieres y te entregue 2 documentos. Un plan de acción con lo que te falta y los próximos pasos, y un registro de logros con historias para entrevistas.

## Antes de empezar

1. Ten tu CV actualizado. Puedes subirlo al chat o conectarlo desde Google Drive para que Claude trabaje con la versión vigente.
2. Activa la búsqueda web para que Claude pueda revisar las ofertas y las empresas.
3. Elige entre 2 y 4 ofertas reales que te interesen y guarda sus enlaces.
4. Opcional. Crea un proyecto en Claude llamado **Mi carrera** y sube ahí tu CV y los documentos que salgan. Así no repites el contexto en cada chat.

---

## Paso 1. Prompt principal

```text
Soy [tu rol actual] con [años] años de experiencia en [área], y vivo en [ciudad, país].
Quiero llegar a estos puestos.
1. [Puesto] en [tipo de empresa], [enlace a la oferta]
2. [Puesto] en [tipo de empresa], [enlace a la oferta]
3. [Puesto] en [tipo de empresa], [enlace a la oferta]

Analiza mi CV frente a estas ofertas y crea 2 documentos.

Documento 1, Plan de acción. Un documento para revisar cada semana con lo que me falta para cada puesto, ordenado por prioridad, 3 a 5 proyectos concretos para cubrir esas brechas, un calendario por trimestre, a qué tipo de personas y empresas contactar, qué estudiar y recursos disponibles en mi país.

Documento 2, Registro de logros. Una hoja de cálculo con mis proyectos y sus resultados medibles, mis habilidades con la evidencia de cada una, logros listos para el CV e historias en formato STAR, que es situación, tarea, acción y resultado, etiquetadas por competencia.

Si algún dato de mi CV no es claro, pregúntame en vez de suponerlo.
```

## Paso 2. Prepara una conversación con alguien del sector

```text
La próxima semana converso con [rol] de [empresa].
Investiga cómo trabaja esa empresa y cómo se posiciona frente a su competencia.
Prepárame una hoja con preguntas para entender sus retos y los puntos de mi experiencia que conviene destacar.
```

## Paso 3. Adapta tu CV a cada puesto

```text
Con mi registro de logros, muéstrame cómo adaptar mi CV para [puesto 1] y para [puesto 2].
Dime qué destacar en cada caso y por qué.
```

## Paso 4. Practica la entrevista

```text
Hazme una entrevista para [puesto] en [tipo de empresa].
Hazme 1 pregunta a la vez y espera mi respuesta.
Después de cada respuesta, dime qué estuvo bien, qué faltó y cómo mejorarla con una de mis historias STAR.
```

## Paso 5. Actualiza el plan cuando cambien tus metas

```text
Encontré esta nueva oferta, [enlace].
Analízala y actualiza mi plan de acción para incluir este camino, manteniendo la misma estructura.
```

---

## Un paso extra recomendado

Antes de elegir qué estudiar, revisa cómo se está usando la IA en el puesto que buscas. Anthropic publica el Anthropic Economic Index, donde puedes ver si en una ocupación la IA se usa más para colaborar o para delegar tareas. Pide a Claude que te ayude a interpretar lo que encuentres.

## Límites honestos

- Claude puede equivocarse con datos del mercado, sueldos o requisitos. Verifica en la oferta original y con personas del sector.
- El plan depende de lo que pongas en tu CV. Si faltan logros o resultados, el registro saldrá incompleto.
- No inventes logros para las historias STAR. En una entrevista te pedirán detalles.
- Revisa qué información personal compartes y en qué herramientas.

## Fuentes

- Claude Academy, caso de uso Plan your career path. https://academy.claude.com/use-cases/plan-your-career-path. Consultado el 4 de noviembre de 2026.
