# Prompts para que la IA no solo te dé la razón

Creado por Stephano, @iOStephano, 8pluscore.com

Basado en el tutorial "What is sycophancy in AI models?" de Claude Academy, de Anthropic.

## Qué es la complacencia

Es cuando la IA te dice lo que quieres oír en lugar de lo que es cierto o útil. Por ejemplo, te da la razón en un error, cambia su respuesta según cómo preguntas o elogia un trabajo que necesita mejoras.

## Cuándo desconfiar más

1. Cuando das una opinión como si fuera un hecho.
2. Cuando citas a un experto.
3. Cuando tu pregunta ya trae una postura.
4. Cuando pides que te valide.
5. Cuando hay emociones de por medio.
6. Cuando la conversación es muy larga.

## Cómo usarlo

Copia el prompt que necesites y pégalo en tu chat con la IA. Los prompts 1 y 2 van al inicio. Los demás, cuando sospeches que solo te está dando la razón.

## Los 7 prompts

**1. Crítica sin rodeos**

> Revisa este trabajo como lo haría un revisor exigente. No me digas lo que hace bien hasta haber listado sus 3 problemas más importantes y cómo corregirlos.
> [pega aquí tu trabajo]

**2. Pregunta neutral**

> Quiero una evaluación objetiva, no apoyo. Si algo de lo que digo es incorrecto o discutible, dímelo con claridad, aunque no sea lo que espero.

**3. El otro lado**

> Dame los mejores argumentos en contra de esta idea, como si tuvieras que convencerme de no hacerla.

**4. Separar opinión de hecho**

> En lo que te dije, separa qué es un hecho comprobable y qué es mi opinión. Para los hechos, dime si son correctos.

**5. Prueba de consistencia**

> Olvida cómo te hice la pregunta. Si alguien sin opinión previa te preguntara esto, ¿qué le responderías?

**6. Nivel de confianza**

> ¿Qué tan seguro estás de esta respuesta? ¿Cambiarías algo si yo no hubiera dado mi opinión antes?

**7. Revisión en un chat nuevo**

Abre un chat nuevo, sin contarle que el trabajo es tuyo ni cómo te sientes con él, y escribe:

> Evalúa este texto. Señala sus puntos débiles y qué cambiarías.
> [pega aquí el texto]

## Además

- Compara la respuesta con fuentes confiables.
- Si la decisión es importante, consulta a una persona de confianza.

## Límite

Estos prompts ayudan a obtener respuestas más honestas, pero no son infalibles. Anthropic reconoce que la complacencia es un problema abierto en toda la industria de la IA.

## Fuente consultada el 4 nov 2026

- Claude Academy, What is sycophancy in AI models?
  https://academy.claude.com/tutorials/what-is-sycophancy-in-ai-models
