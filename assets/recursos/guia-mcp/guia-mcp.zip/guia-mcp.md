# Guía para planificar y revisar un servidor MCP

Creado por Stephano, @iOStephano, 8pluscore.com
Basado en el curso **Introduction to Model Context Protocol** de Anthropic, publicado en Claude Academy.

---

## Cómo usarlo

1. Lee la parte 1 si todavía no tienes clara la diferencia entre servidor y cliente.
2. Usa la tabla de la parte 2 para decidir qué debe ofrecer tu servidor.
3. Copia los prompts de la parte 3 en Claude Code o en el chat de Claude, según el caso.

Reemplaza lo que está entre corchetes. Los prompts 2 y 3 funcionan mejor en Claude Code, porque necesitan leer o escribir archivos de tu proyecto.

---

## Parte 1. Las 2 piezas de MCP

MCP es un protocolo, una forma estándar de que Claude reciba herramientas y datos de servicios externos.

- **Servidor MCP.** Expone lo que puede hacer un servicio externo, como GitHub, en un formato que Claude entiende. Lo puede crear cualquiera. Muchas veces el propio proveedor del servicio publica uno oficial.
- **Cliente MCP.** Vive dentro de tu aplicación. Le pregunta al servidor qué herramientas tiene, le pide ejecutarlas y devuelve el resultado a Claude.

Sin MCP, tendrías que escribir y mantener tú cada herramienta para cada servicio. Con MCP, ese trabajo lo hace el servidor.

---

## Parte 2. Qué debe ofrecer tu servidor

Un servidor MCP puede ofrecer 3 tipos de elementos. La diferencia está en quién decide cuándo se usan.

| Tipo | Quién decide | Úsalo cuando |
|---|---|---|
| Herramientas | Claude | Quieres darle a Claude una capacidad nueva, como buscar, crear o modificar algo en un servicio |
| Recursos | Tu aplicación | Necesitas traer datos de solo lectura para mostrarlos en pantalla o agregarlos como contexto |
| Prompts | El usuario | Quieres ofrecer un flujo de trabajo listo que el usuario activa con un botón o un comando |

---

## Parte 3. Prompts

### Prompt 1. Planificar tu servidor
```
Quiero crear un servidor MCP para conectar Claude con [servicio o sistema].
Lo que necesito que Claude pueda hacer es [lista de tareas].

Propón qué debería ofrecer el servidor, separado en 3 grupos:
1. Herramientas, que Claude decide cuándo usar.
2. Recursos, que son datos de solo lectura que mi aplicación decide cuándo traer.
3. Prompts, que son flujos que el usuario activa.

Para cada elemento, dime el nombre, qué hace y por qué va en ese grupo. Si algo no necesita MCP, dímelo.
```

### Prompt 2. Revisar un servidor MCP antes de conectarlo
```
Antes de conectar este servidor MCP, revisa su código y su documentación, y dime:
1. Quién lo publica y si parece oficial del servicio.
2. Qué herramientas, recursos y prompts expone.
3. A qué servicios externos se conecta.
4. Qué herramientas solo leen datos y cuáles pueden crear, modificar o borrar algo.
5. Qué credenciales o permisos necesita.
No lo ejecutes ni lo conectes. Solo revisa y dame la lista.
```

### Prompt 3. Escribir tu primera herramienta
```
En mi servidor MCP, crea una herramienta llamada [nombre] que [qué hace].
Escribe una descripción clara de la herramienta y de cada parámetro, porque Claude usa esas descripciones para decidir cuándo y cómo llamarla.
Si el dato que recibe no existe, que devuelva un error con un mensaje claro.
Antes de escribir el código, muéstrame la lista de parámetros y espera mi aprobación.
```

### Prompt 4. Plan de prueba con el inspector
El SDK de Python de MCP trae un inspector que se abre en el navegador, donde conectas tu servidor y ejecutas cada herramienta.
```
Arma un plan de prueba para mi servidor MCP en el inspector. Para cada herramienta, dime:
1. Qué valores ingresar para un caso normal.
2. Qué valores ingresar para un caso de error.
3. Qué resultado debería ver.
Incluye una prueba que use 2 herramientas seguidas, por ejemplo editar y luego leer, para confirmar que el cambio se guardó.
```

---

## Recurso oficial del curso

El curso trae un proyecto de inicio, cli_project.zip, en la sección de descargas al final de la lección Defining tools with MCP. Es un chatbot de línea de comandos con un cliente y un servidor MCP en Python. Para usarlo necesitas una clave de la API de Anthropic.
https://academy.claude.com/courses/introduction-to-model-context-protocol/defining-tools-with-mcp

---

## Límite honesto

Esta guía te ayuda a planificar y revisar, pero no reemplaza el curso ni la documentación oficial de MCP. Un servidor MCP puede leer o modificar datos de otros servicios, así que revisa siempre quién lo publica y qué puede hacer antes de conectarlo. Claude también puede equivocarse al revisar código, y la decisión de conectar un servidor es tuya. El inspector y el SDK cambian con nuevas versiones, por eso confirma los detalles en la documentación vigente.

---

## Fuentes

Consultadas el 4 de noviembre de 2026.
- Anthropic, curso Introduction to Model Context Protocol, Claude Academy. https://academy.claude.com/courses/introduction-to-model-context-protocol
- Lección Introducing MCP. https://academy.claude.com/courses/introduction-to-model-context-protocol/introducing-mcp
- Lección MCP clients. https://academy.claude.com/courses/introduction-to-model-context-protocol/mcp-clients
- Lección The server inspector. https://academy.claude.com/courses/introduction-to-model-context-protocol/the-server-inspector
- Lección MCP review. https://academy.claude.com/courses/introduction-to-model-context-protocol/mcp-review
